import fs from 'fs'

// testlog is a log of test results
const testlog = []

// solution function for accurate output comparison
const solutionCounter = function(n) {
  let count = n;
  return function() {
    return count++;
  };
};

// Challenge 1: function is exported properly and callable
try {
  const createCounter = await import('/home/damner/code/index.js').then(module => module.createCounter)

  if (typeof createCounter === 'function') {
    testlog.push({ status: 'pass' })
  } else {
    throw new Error('createCounter is not a function or not exported')
  }
} catch (error) {
  testlog.push({
    status: 'error',
    error: error.message || 'Challenge 1 failed'
  })
}

// Challenge 2: counter function returns the correct sequence of values
try {
  const createCounter = await import('/home/damner/code/index.js').then(module => module.createCounter)
  const userCounter = createCounter(3)
  const solution = solutionCounter(3)
  let pass = true

  for (let i = 0; i < 5; i++) {
    if (userCounter() !== solution()) {
      pass = false
      break
    }
  }

  if (pass) {
    testlog.push({ status: 'pass' })
  } else {
    throw new Error('counter function does not return the correct sequence of values')
  }
} catch (error) {
  testlog.push({
    status: 'error',
    error: error.message || 'Challenge 2 failed'
  })
}

// very important for the final length of `testlog` array to match the number of challenges, in this case - 2.

// write the test log
fs.writeFileSync('/home/damner/code/.labtests/testlog.json', JSON.stringify(testlog))

// write the results array boolean. this will map to passed or failed challenges depending on the boolean value at the challenge index
fs.writeFileSync(process.env.UNIT_TEST_OUTPUT_FILE, JSON.stringify(testlog.map(result => result.status === 'pass')))
